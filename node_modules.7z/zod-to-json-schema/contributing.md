# Contributing

Hey, thanks for wanting to contribute.

Before you open a PR, make sure to open an issue and discuss the problem you want to solve. I will not consider PRs without issues.

I use [gitmoji](https://gitmoji.dev/) for my commit messages because I think it's fun. I encourage you to do the same, but won't enforce it.

I check PRs and issues very rarely so please be patient.
