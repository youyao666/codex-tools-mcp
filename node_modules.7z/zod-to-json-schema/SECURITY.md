# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 3.9.x   | :white_check_mark: |
| < 3.9   | :x:                |

## Reporting a Vulnerability

Please log an issue [here](https://github.com/StefanTerdell/zod-to-json-schema/issues)
