import { writeFileSync } from "fs";

writeFileSync("./dist/esm/package.json", '{"type":"module","main":"index.js"}', "utf-8");
