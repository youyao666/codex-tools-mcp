/* included for compatibility with react-native without package exports support */
module.exports = require('./dist/stream.cjs')
