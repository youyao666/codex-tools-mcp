declare function mod(number: number, modulo: number): number;

export = mod;